$
int somaTudo)(SumArray<int> v[], int n){}
