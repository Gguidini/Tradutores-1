int main(){
	int x;
	x = x[1] + x[1,2];
	int y[10];
	y[2] = y[1] + y[2];
	y[3] = y[1,3];
}
