int n, m, a;

int f(int n){
	int n;
}

int main(){
	int n, m, a;
	int m;
	if(m == 3){
		int a;
	} else if(m == 2){
		int a;
	}
	else{
		int a;
	}

}

int a;

int x(int a, int b, int c, int c){
	int x, b;
}

int x(){
	int a;
}
