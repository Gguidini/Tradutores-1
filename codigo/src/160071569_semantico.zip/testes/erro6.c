int f(int a, int b, int c){
	return 1;
}
int a;
int main(){
	f(1, 23);
	f(1, 23.0, 212);
}
