int func (int a, float asd, int vc) {
	int func, b, c, d[10];
	return d[1,3];
	xz = 12;
	int x;
	if(x==3){
		while(batata[123] = 123 + 2304 / (123 + asd) - (2) ){
			d[2,3] += ewew;
			func(1, 12, 23);
			func2(1, 12, 23);
		}
	}
	outInt d;
	inInt dxd;
}
