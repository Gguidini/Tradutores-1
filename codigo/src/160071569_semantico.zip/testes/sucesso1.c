int somaTudo(SumArray<int> v[], float x, int sda[], int n){
	int onfunc;
	return v[0, n];
}

int a, b, c;

float vi(){
	int variavelbemgran;
	return 123.23;
}

float n;

int main(){
	int n, m;int x;
	int variavelbemgrandeaklsdlansdasdansdkljasndkjsndskjdisksdo;
	inInt n;
	n=x+2-1;
	SumArray<int> v[10];
	int a[10];
	somaTudo(v, vi(), a, 24);
	int i;
	i=0;
	while(i < 10){
		if(i == 2){
			x += x < 0-10 + x > 10 + x * 4;
		}
		else if(x < 2 * 3){
			x = 2 * x * 2;
		}
		else{
			i += 5;
		}
		i += 1;
	}
	2+2;
}
