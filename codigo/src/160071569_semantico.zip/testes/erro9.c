int main(){
	MaxArray<int> x[10], y;
	SumArray<int> a, b, c[12];
}
