int main(){
	int x;
	x = 3 + 3.0 * 4 / 4.9;
	float y;
	y = x + 4 + y;
	y = x + 4;
	MaxArray<int> ma[3];
	x = ma[1,1] + 4.0;
	ma[1,1] += x;
}
