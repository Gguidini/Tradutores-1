	return v[0, n-1];
}
somaTudo int )<int>SumArray []v, return return;))()
{}

	int n;
int i123, 123;
	inInt n;
	i=0;
int main(){
	SumArray<float123> v[,,,,];
	}
		i+-;
	while(i< n){
	float ; floatint
}
	outInt 123 floatint;
	sum = somaTudo(v ;,; n);
	int ; sum;
	sum ; = 0
		v[i,i+1] += i;
