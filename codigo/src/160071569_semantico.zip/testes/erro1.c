int main(){
	int x = 12312312ljasdjhasdkj;
	return 1223x;
}
